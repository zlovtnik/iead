#!/bin/sh
# Start the Church Management System

# Make the app executable
chmod +x app.lua

# Run the app
lua app.lua
